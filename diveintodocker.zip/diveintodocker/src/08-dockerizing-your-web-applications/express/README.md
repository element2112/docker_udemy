# NodeJS

This NodeJS application is a slightly more optimized version of the Voting App
that we looked at before.
